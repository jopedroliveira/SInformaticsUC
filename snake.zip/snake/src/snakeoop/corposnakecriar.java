package snakeoop;

public class corposnakecriar {
	int x,y;
	String car = null;
	public corposnakecriar(){
		this.x = 80;
		this.y = 80;
		this.car = "K";
	}
}