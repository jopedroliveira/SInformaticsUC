package snakeoop;

public class criarObjeto {

	int x,y;
	public criarObjeto(){
		posicao posi = new posicao();
		this.x = posi.x;
		this.y = posi.y;
	}

}
