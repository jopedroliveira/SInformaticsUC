package snakeoop;

public class printMapa {

	public printMapa(String[][] mapamapaq){
		for(int ii = 0; ii< mapamapaq.length; ii++){ 
			for(int jj = 0; jj<mapamapaq[0].length;jj++){
				System.out.print(mapamapaq[ii][jj]);
			}
			System.out.print("\n");
		}
	}
}

